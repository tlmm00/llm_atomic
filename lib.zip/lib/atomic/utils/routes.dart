enum Routes {
  home, preview, download, prompts, AddImagesPage
}