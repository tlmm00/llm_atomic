class Prompt {

  //TODO: adicionar novos campos 

  final String text;
  final bool isUserMessage;

  Prompt({required this.text, required this.isUserMessage});
}